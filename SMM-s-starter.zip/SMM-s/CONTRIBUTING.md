# Contributing to SMM-s

Thanks for your interest in contributing.

## Before you start

1. Check existing issues to avoid duplicate work.
2. For substantial changes, open an issue first to discuss the proposed approach.
3. Keep pull requests focused and explain the problem they solve.

## Local setup

- Install Python 3.10 or newer.
- Clone the repository.
- Run `python app.py help`.
- Run tests with `python -m unittest discover -s tests -v`.

## Pull request checklist

- [ ] The change has a clear purpose.
- [ ] Tests were added or updated where appropriate.
- [ ] Existing tests pass.
- [ ] Documentation reflects user-visible changes.
- [ ] No secrets, tokens, or personal data were committed.

Please be respectful and constructive in issues and reviews.
