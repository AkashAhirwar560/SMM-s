# Security policy

SMM-s is an early-stage project. Please do not publish passwords, API tokens, access keys, or private personal information in issues.

For a suspected security vulnerability, contact the repository maintainer privately through a contact method listed on their GitHub profile. Include steps to reproduce and the potential impact. Avoid posting exploit details publicly until a fix can be discussed.

Do not use this tool to store credentials. The current prototype stores post captions and scheduling metadata locally in a JSON file.
