# SMM-s

SMM-s is a small, local-first social media marketing planner. The initial version helps you draft posts, organize them by platform and status, and export a content calendar as CSV.

> **Project status:** Early prototype. This version does not publish posts, connect to social networks, or provide analytics. Those capabilities would require separate implementation, testing, and (where applicable) official API access.

## Features

- Add draft posts with platform, scheduled date, caption, and status.
- List saved posts.
- Update a post's status.
- Export the calendar to CSV.
- Store data locally in a JSON file.

## Requirements

- Python 3.10 or newer
- No third-party packages required

## Quick start

```bash
python app.py help
python app.py add --platform Instagram --date 2026-11-01 --caption "Share a behind-the-scenes look at the project."
python app.py list
python app.py export --output content-calendar.csv
```

Run `python app.py help` to see all commands. The first run creates `data/posts.json` automatically.

## Commands

```text
python app.py add --platform PLATFORM --date YYYY-MM-DD --caption TEXT [--status STATUS]
python app.py list
python app.py status --id ID --value STATUS
python app.py export [--output FILE]
```

Allowed statuses: `idea`, `draft`, `scheduled`, `published`.

## Data and privacy

Posts are saved on your device in `data/posts.json`. The tool does not send data to a server. Do not store passwords, access tokens, or other secrets in post captions or the repository.

## Development and tests

Run the test suite with:

```bash
python -m unittest discover -s tests -v
```

## Roadmap

- [x] Local post planning and CSV export
- [ ] Add date-range filtering
- [ ] Add editable post support
- [ ] Evaluate official platform APIs before considering publishing integrations

Roadmap items are planned, not implemented.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Bug reports and small, focused improvements are welcome.

## License

Released under the MIT License. See [LICENSE](LICENSE).
