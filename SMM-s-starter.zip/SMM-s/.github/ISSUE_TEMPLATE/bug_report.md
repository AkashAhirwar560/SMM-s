---
name: Bug report
about: Report a reproducible problem
title: "[Bug]: "
labels: bug
assignees: ""
---

## What happened?
Describe the problem.

## Steps to reproduce
1.
2.
3.

## Expected behavior
What did you expect?

## Environment
- OS:
- Python version:
- SMM-s version/commit:

## Additional context
Add relevant logs, without secrets or personal data.
