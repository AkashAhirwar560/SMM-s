import tempfile
import unittest
from pathlib import Path

from app import add_post, change_status, export_csv, load_posts


class PlannerTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_file = Path(self.temp_dir.name) / "posts.json"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_add_and_load_post(self):
        post = add_post("Instagram", "2026-11-01", "Test caption", path=self.data_file)
        self.assertEqual(post["id"], 1)
        self.assertEqual(load_posts(self.data_file)[0]["caption"], "Test caption")

    def test_status_update(self):
        post = add_post("LinkedIn", "2026-11-02", "A professional update", path=self.data_file)
        changed = change_status(post["id"], "scheduled", path=self.data_file)
        self.assertEqual(changed["status"], "scheduled")

    def test_reject_invalid_date(self):
        with self.assertRaises(ValueError):
            add_post("Instagram", "tomorrow", "Caption", path=self.data_file)

    def test_reject_empty_caption(self):
        with self.assertRaises(ValueError):
            add_post("Instagram", "2026-11-01", "  ", path=self.data_file)

    def test_export_csv(self):
        add_post("Instagram", "2026-11-01", "CSV caption", path=self.data_file)
        output = Path(self.temp_dir.name) / "calendar.csv"
        count = export_csv(output, path=self.data_file)
        self.assertEqual(count, 1)
        self.assertIn("CSV caption", output.read_text(encoding="utf-8-sig"))


if __name__ == "__main__":
    unittest.main()
