"""A small local-first social media content planner for SMM-s."""
from __future__ import annotations

import argparse
import csv
import json
from datetime import date, datetime
from pathlib import Path
from typing import Any

DATA_FILE = Path("data/posts.json")
STATUSES = {"idea", "draft", "scheduled", "published"}
FIELDS = ["id", "platform", "scheduled_date", "caption", "status", "created_at"]


def load_posts(path: Path = DATA_FILE) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise ValueError(f"Could not read post data from {path}: {exc}") from exc
    if not isinstance(data, list):
        raise ValueError(f"Expected a list of posts in {path}")
    return data


def save_posts(posts: list[dict[str, Any]], path: Path = DATA_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(json.dumps(posts, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temp_path.replace(path)


def add_post(platform: str, scheduled_date: str, caption: str, status: str = "draft",
             path: Path = DATA_FILE) -> dict[str, Any]:
    try:
        date.fromisoformat(scheduled_date)
    except ValueError as exc:
        raise ValueError("Date must use YYYY-MM-DD format") from exc
    status = status.lower()
    if status not in STATUSES:
        raise ValueError(f"Status must be one of: {', '.join(sorted(STATUSES))}")
    if not platform.strip():
        raise ValueError("Platform cannot be empty")
    if not caption.strip():
        raise ValueError("Caption cannot be empty")

    posts = load_posts(path)
    next_id = max((int(p.get("id", 0)) for p in posts), default=0) + 1
    post = {
        "id": next_id,
        "platform": platform.strip(),
        "scheduled_date": scheduled_date,
        "caption": caption.strip(),
        "status": status,
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    posts.append(post)
    save_posts(posts, path)
    return post


def change_status(post_id: int, status: str, path: Path = DATA_FILE) -> dict[str, Any]:
    status = status.lower()
    if status not in STATUSES:
        raise ValueError(f"Status must be one of: {', '.join(sorted(STATUSES))}")
    posts = load_posts(path)
    for post in posts:
        if int(post.get("id", -1)) == post_id:
            post["status"] = status
            save_posts(posts, path)
            return post
    raise ValueError(f"No post found with id {post_id}")


def export_csv(output: Path, path: Path = DATA_FILE) -> int:
    posts = load_posts(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(posts)
    return len(posts)


def print_posts(posts: list[dict[str, Any]]) -> None:
    if not posts:
        print("No posts yet. Add one with the 'add' command.")
        return
    for post in sorted(posts, key=lambda p: (p.get("scheduled_date", ""), p.get("id", 0))):
        caption = str(post.get("caption", "")).replace("\n", " ")
        if len(caption) > 72:
            caption = caption[:69] + "..."
        print(f"#{post.get('id')} | {post.get('scheduled_date')} | "
              f"{post.get('platform')} | {post.get('status')} | {caption}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Local-first social media content planner.")
    sub = parser.add_subparsers(dest="command")

    add = sub.add_parser("add", help="Add a post to the calendar")
    add.add_argument("--platform", required=True, help="Platform or channel name")
    add.add_argument("--date", dest="scheduled_date", required=True, help="Date in YYYY-MM-DD format")
    add.add_argument("--caption", required=True, help="Draft caption text")
    add.add_argument("--status", default="draft", choices=sorted(STATUSES))

    sub.add_parser("list", help="List all saved posts")

    status = sub.add_parser("status", help="Change a post's status")
    status.add_argument("--id", type=int, required=True, help="Post ID")
    status.add_argument("--value", required=True, choices=sorted(STATUSES), help="New status")

    export = sub.add_parser("export", help="Export posts to CSV")
    export.add_argument("--output", default="content-calendar.csv", help="Output CSV filename")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 0
    try:
        if args.command == "add":
            post = add_post(args.platform, args.scheduled_date, args.caption, args.status)
            print(f"Added post #{post['id']} for {post['scheduled_date']}.")
        elif args.command == "list":
            print_posts(load_posts())
        elif args.command == "status":
            post = change_status(args.id, args.value)
            print(f"Post #{post['id']} status changed to {post['status']}.")
        elif args.command == "export":
            count = export_csv(Path(args.output))
            print(f"Exported {count} post(s) to {args.output}.")
        return 0
    except (ValueError, OSError) as exc:
        print(f"Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
